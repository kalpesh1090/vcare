<div class="page-header page-header-light">

	<div class="breadcrumb-line breadcrumb-line-light header-elements-lg-inline">
		<div class="d-flex">
			<div class="breadcrumb">
				<a href="index.html" class="breadcrumb-item"><i class="icon-home2 mr-2"></i> Home</a>
				<span class="breadcrumb-item active">Update Profile</span>
			</div>

			<a href="#" class="header-elements-toggle text-body d-lg-none"><i class="icon-more"></i></a>
		</div>

		
	</div>
</div>
<div class="content">

	<!-- Form inputs -->
	<div class="card">
		

		<div class="card-body">
			
			<form action="#">
				<fieldset class="mb-3">
					<div class="form-group row">
						<label class="col-form-label col-lg-2">Eamil</label>
						<div class="col-lg-4">
							<input type="text" class="form-control" value="kalpesh@cranti.com" disabled >
						</div>
					</div>

					<div class="form-group row">
						<label class="col-form-label col-lg-2">First Name</label>
						<div class="col-lg-4">
							<input type="text" class="form-control" placeholder="First Name">
						</div>
					</div>

					<div class="form-group row">
						<label class="col-form-label col-lg-2">Last Name</label>
						<div class="col-lg-4">
							<input type="text" class="form-control" placeholder="Last Name">
						</div>
					</div>

					<div class="form-group row">
						<label class="col-form-label col-lg-2">Mobile Number</label>
						<div class="col-lg-4">
							<input type="text" class="form-control" placeholder="mobile Number">
						</div>
					</div>
					<div class="form-group row">
						
						<div class="offset-md-2 col-lg-4">
							<input type="submit" class="btn btn-primary" value="Update" >
						</div>
					</div>

					
				</fieldset>

			</form>
		</div>
	</div>
	<!-- /form inputs -->

</div>